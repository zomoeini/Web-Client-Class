$(document).ready(function () {
    const quotes = [
      "Believe in yourself.",
      "You are stronger than you think.",
      "Keep going. You're doing great!",
      "The best time for new beginnings is now.",
      "Mistakes are proof that you're trying."
    ];
  
    function showRandomQuote() {
      const randomIndex = Math.floor(Math.random() * quotes.length);
      const quote = quotes[randomIndex];
      $("#quote-text").fadeOut(200, function () {
        $(this).text(quote).fadeIn(200);
      });
    }
  
    $("#new-quote").click(function () {
      showRandomQuote();
    });
  
    // Show one on page load
    showRandomQuote();
  });