// write my first jQuery 
// jQuery code is easy to recognize always start with $


// ready function : ensures that the code runs only after the page is fully loaded 
$(document).ready(function() {

    // EventListener 
    $("#hideBtn").click(function() {
        $("#text").hide();
    });


// selecting Elements 

    // I will add function for event then inside the event I will add my functions
    $("#changeText").click(function() {
        $("#para1").text("Text Changed!");// select by Id
        // when we use the css function to change the style first we provide property the value 
        $(".para").css("color","red");// select by Class
        $("p").css("font-size","18px"); // select by Tag
    });


// Hode and show 

    // add event to my element 
    $("#hide").click(function() {
        $("#hiddenText").hide();
    });
    $("#show").click(function() {
        $("#hiddenText").show();
    });


// Fading Effects 

    // add event for button
    $("#fadeOut").click(function() {
        $("#fadeText").fadeOut();
    });

    // again add event to another button
    $("#fadeIn").click(function() {
        $("#fadeText").fadeIn();
    });


// form validation 
// add event to the submit button 
$("#contactForm").submit(function(event) {
// prevent to submit the form unless we do the validation 
    event.preventDefault();
    // let name = document.getElementById("").value()
    let name = $("#name").val();
    let email = $("#email").val();

    // none of my inputs should be empty 
    if(name == "" || email == "") {
        // set error Message 
        $("#errorMessage").text("All fields are required!");
    }else {
        $("#errorMessage").text("Form submitted successfully!");
    }
});

// toggle in jQuery()  switches the vidibility of element to on and  off change the binary status to 0 or 1 
    $("#toggleButton").click(function() {
        $("#demo").slideToggle("slow");
    });


    // toggle for speed 
    // $().toggle(1000);

    // I want to have input that user only puts numbers 
    // create a function to validate the data 
    function isNumber(number) {
        // use Regex 
        // create or desgin the pattern 
        // Regex or pattern is always string 
        // always starts with "^" and ends "$"
        // put the patter in [] +[]+ patterns
        // only numbers [0-9] ; only letters [a-zA-Z] (only lowercase)
        const numberPattern = /^[0-9]+$/;
        // get the date compare to pattern 
        // if is match return true else we will return false
        return numberPattern.test(number);
    }

    // form submit event 
    $("#numberForm").submit(function(event) {
        event.preventDefault();

        // get the data 
        const numberText = $("#number").val();
        // parse to int change dataType from string to int 
        const number = parseInt(numberText,10);

        // validate the data
        if(isNumber(number)) {
            $("#errorNumnbers").text("This is a number and form submitted!");
        }else {
            $("#errorNumnbers").text("Only digit numbers accepted")
        }
    })
});

