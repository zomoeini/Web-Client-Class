function myFunction() {
    document.getElementById('demo').style.fontSize = '70px';
}
function showCalcul(){

    document.getElementById('myCalcul').innerHTML = '12';
}